/* JavaScript function to create the grid when submit button is clicked.
 * It takes the height and width of the grid from the html form and creates
 * the grid on the table in html page.*/
function makeGrid() {
    var height = document.getElementById('height').value;
    var width = document.getElementById('width').value;
    var table = document.getElementById('pixel_canvas');
//creation of table grid
    table.innerHTML = '';
    var tbody = document.createElement('tbody');
    for (var i = 0; i < height; i++) {
        var tr = document.createElement('tr');
        for (var j = 0; j < width; j++) {
            var td = document.createElement('td');
            td.appendChild(document.createTextNode(''));
            tr.appendChild(td);
        }
        tbody.appendChild(tr);
    }
    table.appendChild(tbody);
}
//jquery to change the color when clicked
$('body').on('click', 'td', function() {
	var color = document.getElementById('colorPicker').value;
  $(this).css('background-color', color);
});
